import React, { useEffect, useState } from "react";

const AdminDashboard = () => {
  const [forms, setForms] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/forms")
      .then((res) => res.json())
      .then((data) => setForms(data))
      .catch((err) => console.error("Error fetching forms:", err));
  }, []);
  const styles = {
    container: {
      textAlign: "center",
      padding: "50px",
      fontFamily: "Arial, sans-serif",
      backgroundColor: "#f4f4f4",
      borderRadius: "10px",
      boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
      maxWidth: "800px",
      margin: "auto",
    },
    button: {
      backgroundColor: "#008080",
      color: "white",
      padding: "10px 20px",
      border: "none",
      borderRadius: "5px",
      cursor: "pointer",
      fontSize: "16px",
      marginTop: "15px",
    }
  };


  return (
    <div style={styles.container}>
      <h2>Admin Dashboard - Submitted Forms</h2>
      <table border="1" className="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Age</th>
            <th>Contact</th>
            <th>Blood Group</th>
            <th>Adhaar</th>
            <th>BPL</th>
            <th>Recommended Hospital</th>

          </tr>
        </thead>
        <tbody>
          {forms.map((form) => (
            <tr key={form.id}>
              <td>{form.id}</td>
              <td>{form.name}</td>
              <td>{form.age}</td>
              <td>{form.contact}</td>
              <td>{form.bloodgroup}</td>
              <td>{form.adhaar}</td>
              <td>{form.bpl}</td>
              <td>{form.symptoms}</td>

            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AdminDashboard;
