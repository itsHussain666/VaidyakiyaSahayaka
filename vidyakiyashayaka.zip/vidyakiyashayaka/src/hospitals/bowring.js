import React from "react";
import bowring from "./bowring.png"




const Bowring=()=>{
    return (
        <div align="center" >
            <img src={bowring} height="300" width="600" align="center"/>
        <div className="results-container">
      <h1>Welcome to Bowring and Lady Curzon Hospitals </h1>
      <h5>Yours Trusted Multi-Speciality Health Care center in Bengaluru.</h5>
      <div >
      owring and Lady Curzon Hospitals (BLCH) is a teaching hospital and autonomous university in Bengaluru, Karnataka, India. 
      It was originally a medical institution belonging to Mysore State, but in 1884 it was made over to the Civil and Military Administration. 
      This hospital was only the Civil Medical Institution of Bengaluru till 1890. It had accommodation for 104 beds, of which 80 were for men and 24 for women patients.
       Additional accommodation for female patients was provided by the donations contributed by philanthropic citizens and by the Government of India. Sri Atal Bihari Vajpayee Medical College and Research Institute inaugurated on 29 December 2020 is located close by.<br/>

Located in Shivajinagar in the city's central business district, the 152-year-old hospital has also taught students pursuing medical degrees since the late 19th century during the British Raj.. <br/>
    <b>Services / Facilities provided in Bowring & Lady Curzon Hospitals</b>  <br/>
 
* INPATIENT SERVICES<br/>

* OUT PATIENT SERVICES<br/>

* LAB SERVICES<br/>

* X-RAY SERVICES<br/>

* USG SERVICES<br/>

* CT SCANNING SERVICES<br/>

* VACCINATION SERVICE<br/>

* KANGAROO MOTHER CARE<br/>

* SNCU<br/>

* ID NAT FACILITY<br/>

* TELE MEDICINE<br/>

* DIALYSIS<br/>

* ARECENTRE (HIV) –NODAL CENTRE<br/>

* ARTIFICIAL LIMB CENTRE<br/>

* JOINT REPLACEMENT CENTRE WITH MODULAR OT <br/>

* PHARMACY<br/>

* BLOOD BANK<br/>

* RAKTHA KOSHA LINK<br/>

 

 
      </div>
      <div >
        <b>Address:</b>
        Lady Curzon Rd, Tasker Town, Shivajinagar, Bengaluru, Karnataka 560001.<br/>
        <b>	General:</b> 080 2559 1325

     <br/>
          <b>Emergency Helpline Number:</b>080 2559 1325.

      </div>
      <br/>
      <a href="https://sabvmcri.karnataka.gov.in/info-2/Bowring+and+Lady+Curzon+Hospitals/en">
      <button className="btn btn-primary"  onClick={() => alert('Thank you for visiting!')}>Know More</button></a>
    </div>
        </div>
    )
};
const styles = {
  container: {
    textAlign: "center",
    padding: "50px",
    fontFamily: "Arial, sans-serif",
    backgroundColor: "#f4f4f4",
    borderRadius: "10px",
    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
    maxWidth: "600px",
    margin: "auto",
  }};
 export default Bowring;