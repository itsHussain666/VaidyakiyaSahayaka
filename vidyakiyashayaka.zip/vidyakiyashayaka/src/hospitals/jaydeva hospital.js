import React from "react";
import jayadeva from "./jayadeva.jpg"

const Jaydeva=()=>{
    return (
        <div align="center" >
            <img src={jayadeva} height="300" width="600" align="center"/>
        <div className="results-container">
      <h1>Welcome to Jayadeva Hospital</h1>
      <h5>Your trusted cardiology hospital in Bangalore.</h5>
      <div >
      Sri Jayadeva Institute of Cardiovascular Sciences and Research is a Government run Autonomous Institute 
      with 1150 Beds exclusively for Cardiac care and is one of the largest single centre for heart care destination in South East Asia. 
      This is purely a Non-Profit Organization with State of Art Cardiac Care, providing quality cardiac care at an affordable cost to all sections of the society and free of cost in deserving poor. 
      We have effectively implemented “Treatment First – Payment Next” Concept where in the cardiac patient requiring emergency admission, shall be done without insisting for any advance payment. 
      Institute has recorded 400% growth in last 10years.
      </div>
      <div >
        <b>Address:</b> B-8, B T M I Stage, Marenahalli Rd, KEB Colony, Jayanagara 9th Block, Jayanagar, Bengaluru, Karnataka 560041.<br/>
        <b>GENERAL ENQUIRY/ EPABX :	</b> +91-80-2297-7400 / 2297-7600 / 2653-4600 (24 Hours)
          <br/>
          <b>Emergency No :</b> +91-80-2297-7202 / 679 (24 Hours)
      </div>
      <br/>
      <a href="">
      <button className="btn btn-primary"  onClick={() => alert('Thank you for visiting!')}>Know More</button></a>
    </div>
        </div>
    )
};
const styles = {
  container: {
    textAlign: "center",
    padding: "50px",
    fontFamily: "Arial, sans-serif",
    backgroundColor: "#f4f4f4",
    borderRadius: "10px",
    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
    maxWidth: "600px",
    margin: "auto",
  }};
 export default Jaydeva;