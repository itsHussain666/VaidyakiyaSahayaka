import React from "react";
import nimhans from "./NIMHANS.jpg"

const NIMHANS=()=>{
    return (
        <div align="center" >
            <img src={nimhans} height="300" width="600" align="center"/>
        <div className="results-container">
      <h1>Welcome to The National Institute of Mental Health and Neuro-Sciences (NIMHANS) </h1>
      <h5>Yours Trusted Mental Health care center in Bangalore.</h5>
      <div >
      The National Institute of Mental Health and Neuro-Sciences (NIMHANS) is a medical institution in Bengaluru, India.[7] NIMHANS serves as the apex centre for mental health education and neuroscience research in the country.
       It is an Institute of National Importance operating autonomously under the Ministry of Health and Family Welfare.[8] NIMHANS is ranked 4th best medical institute in India, in the current National Institutional Ranking Framework.
       NIMHANS has five campuses in the city, spread over an area of 174 acres of urban establishments, which includes 30 acres of an under-construction Bangalore North campus.
       The main campuses of the institute are located in Byrasandra (hospital wing) and Lakkasandra (academic and administrative wing) localities on either side of the Hosur Road.
       The 'Community Mental Health Center' is located in the Sakalawara area on Bannerghatta Road.[18] The 'NIMHANS Centre for Well Being' is situated in a residential area in BTM Layout.[19]
        A state-of-the-art convention centre located in the main campus frequently hosts international conferences, seminars, trade shows, expositions, and media events.[20][21]
      </div>
      <div >
        <b>Address:</b>NIMHANS Hospital
Hosur Road / Marigowda Road, Lakkasandra, Wilson Garden, Bengaluru, Karnataka 5600291.<br/>
        <b>	General:</b>080 2699 5001
     <br/>
          <b>Emergency Helpline Number:</b> 080 2699 5001
      </div>
      <br/>
      <a href="www.nimhans.ac.in">
      <button className="btn btn-primary"  onClick={() => alert('Thank you for visiting!')}>Know More</button></a>
    </div>
        </div>
    )
};
const styles = {
  container: {
    textAlign: "center",
    padding: "50px",
    fontFamily: "Arial, sans-serif",
    backgroundColor: "#f4f4f4",
    borderRadius: "10px",
    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
    maxWidth: "600px",
    margin: "auto",
  }};
 export default NIMHANS;