import React from "react";
import kims from "./kimshospital.jpg"

const KIMS=()=>{
    return (
        <div align="center" >
            <img src={kims} height="300" width="600" align="center"/>
        <div className="results-container">
      <h1>Welcome to Kempegowda Institute Of Medical Sciences (KIMS)</h1>
      <h5>Yours Trusted Multi-Speciality Health Care center in Bengaluru.</h5>
      <div >
      The KIMS hospital was established in the year 1990 and is located in the heart of Bangalore city and in close proximity to the City market.
       It is a multi speciality hospital having 1100 beds offering services ranging from Medicine, Surgery,ObstetricsandGynecology,Pediatrics,Dermatology,ENT,Opthalmology, Preventive Medicine, Forensic Post-mortem facility and Pathology,Microbiology ,Biochemistry investigational facilities.
       It fulfils the requirements of the Medical council of India with respect to MBBS and Postgraduate courses.
       <br/>
      <b> Values & Quality</b><br/>
KIMS stands for the value : “Satata Seva Tatparate” (in Sanskrit) meaning “Always devoted to service”
Motto of KIMS hospital: To provide high quality patient care at an affordable cost and cater to the needs of all sections of the society
      </div>
      <div >
        <b>Address:</b>
        Lalbagh Fort Rd, K.R Road, V.V Puram, Bengaluru, Karnataka 560004.<br/>
        <b>	General:</b>080 2661 3225.

     <br/>
          <b>Emergency Helpline Number:</b> 080 2661 3225.

      </div>
      <br/>
      <a href="https://www.kimsbangalore.edu.in/">
      <button className="btn btn-primary"  onClick={() => alert('Thank you for visiting!')}>Know More</button></a>
    </div>
        </div>
    )
};
const styles = {
  container: {
    textAlign: "center",
    padding: "50px",
    fontFamily: "Arial, sans-serif",
    backgroundColor: "#f4f4f4",
    borderRadius: "10px",
    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
    maxWidth: "600px",
    margin: "auto",
  }};
 export default KIMS;