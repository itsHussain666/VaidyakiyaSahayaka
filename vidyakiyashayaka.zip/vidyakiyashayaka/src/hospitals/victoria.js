import React from "react";
import victoria from "./victoria.jpg"




const Victoria=()=>{
    return (
        <div align="center" >
            <img src={victoria} height="300" width="600" align="center"/>
        <div className="results-container">
      <h1>Welcome to Victoria Hospital</h1>
      <h5>Yours Trusted Multi-Speciality Health Care center in Bengaluru.</h5>
      <div >
      Victoria Hospital is a government run hospital affiliated with Bangalore Medical College and Research Institute. 
      It is the largest hospital in Bengaluru, India. Started by Shri Krishna Raja Wadiyar IV, the then Maharaja of Mysuru in 1900, the hospital soon rose to be among the prominent hospitals in South India.
       Dr. Padmanabhan Palpu, a famous doctor and bacteriologist from Kerala was instrumental in setting up the hospital.
      [1] Victoria Hospital is one of Bengaluru's oldest and most prestigious medical institutions.
      <br/>
      <br/>
      <b> Emergency services</b> are available 24 hours including traumatology and emergency surgery in the Mahabodhi Burns and Casualty block with a 24-hour blood bank. 
      The burns department housed in the same building is among the best in Karnataka and is managed by the Plastic Surgery department.
       A centralized laboratory modernized with a grant from Infosys provides 24-hour services.
        The outpatient department housed in the Sir Puttanna Chetty block has a pharmacy that supplies medicines free to poor patients.
         The main building houses the administrative offices and wards. The centenary building houses new wards and the nuclear medicine department with gamma camera and modern operation theatres. The radiology department is in the B.M. Srinivasaiah block. The E.N.T department is in the Venkateshwara Institute. 
      A dharmashala on the hospital campus provides subsidized accommodation for patient's companions.
      </div>
      <div >
        <b>Address:</b>
        City Market, Fort Road, Bengaluru, Karnataka 560002.<br/>
        <b>	General:</b> 080 2670 1150.

     <br/>
          <b>Emergency Helpline Number:</b>080 2670 1150.

      </div>
      <br/>
      <a href="https://victoriahospital.karnataka.gov.in/english">
      <button className="btn btn-primary"  onClick={() => alert('Thank you for visiting!')}>Know More</button></a>
    </div>
        </div>
    )
};
const styles = {
  container: {
    textAlign: "center",
    padding: "50px",
    fontFamily: "Arial, sans-serif",
    backgroundColor: "#f4f4f4",
    borderRadius: "10px",
    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
    maxWidth: "600px",
    margin: "auto",
  }};
 export default Victoria;