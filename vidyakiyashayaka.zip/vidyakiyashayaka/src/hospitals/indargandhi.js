import React from "react";
import indiragandhi  from "./indiragandhji.jpg"

const IndiraGandhi=()=>{
    return (
        <div align="center" >
            <img src={indiragandhi} height="300" width="600" align="center"/>
        <div className="results-container">
      <h1>Welcome to Indira Gandhi Institute Of Child Health Hospital</h1>
      <h5>Yours Trusted Child Care center in Bengaluru.</h5>
      <div >
      Indira Gandhi Institute of Child Health is a premier organization promoting Child Health Care services. 
       It is an autonomous body registered under Karnataka Societies Registration Act 1960 as 'Institute of Child Health, Karnataka' on 06.08.1985 and aided by Government of Karnataka, since 1991. 
       It is a non-profit organization located in its own premises next to the National Institute of Mental Health and Neuro-Sciences at South Hospital Complex in Bangalore.
      </div>
      <div >
        <b>Address:</b>
        South Hospital Complex, Near Nimhans, Hombegowda Nagar, Bengaluru, Karnataka 560029.<br/>
        <b>	General:</b> 080 2244 3143.

     <br/>
          <b>Emergency Helpline Number:</b> 080 2244 3143.

      </div>
      <br/>
      <a href="https://igich.karnataka.gov.in/english">
      <button className="btn btn-primary"  onClick={() => alert('Thank you for visiting!')}>Know More</button></a>
    </div>
        </div>
    )
};
const styles = {
  container: {
    textAlign: "center",
    padding: "50px",
    fontFamily: "Arial, sans-serif",
    backgroundColor: "#f4f4f4",
    borderRadius: "10px",
    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
    maxWidth: "600px",
    margin: "auto",
  }};
 export default IndiraGandhi;