import React from "react";
import sanjaygandhi from "./sanjaygandhi.jpg"

const SanjayGandhi=()=>{
    return (
        <div align="center" >
            <img src={sanjaygandhi} height="300" width="600" align="center"/>
        <div className="results-container">
      <h1>Welcome to Sanjay Gandhi Institute of Trauma and Orthopaedics</h1>
      <h5>Yours Trusted Trauma and Orthopaedics center in Bangalore.</h5>
      <div >
      Sanjay Gandhi Institute of Trauma and Orthopaedics (SGITO) is a specialised tertiary trauma and orthopaedics institute with emphasis on specialised surgery,
       prompt postoperative care, rehabilitation, and promoting research activities. 
       As one of the leading regional trauma and orthopaedic speciality hospitals,
        we are dedicated to improving patient results by providing high-quality, cost-effective specialized trauma and orthopaedic care 
        in a streamlined environment focused on wellness, mobility, and quick recovery. The institute also has a dedicated team of plastic surgeons which goes hand in hand as a speciality for trauma cases along with orthopedicians.
      </div>
      <div >
        <b>Address:</b>
Sanjay Gandhi Institute of Trauma & Orthopaedics
1st Block, Byrasandra
Jayanagar East
Bangalore -560 011.<br/>
        <b>	General:</b> 080-26564516, 26944300, 26566000.
     <br/>
          <b>Emergency Helpline Number:</b> 080-2656 4516.
      </div>
      <br/>
      <a href="https://sgito.org/">
      <button className="btn btn-primary"  onClick={() => alert('Thank you for visiting!')}>Know More</button></a>
    </div>
        </div>
    )
};
const styles = {
  container: {
    textAlign: "center",
    padding: "50px",
    fontFamily: "Arial, sans-serif",
    backgroundColor: "#f4f4f4",
    borderRadius: "10px",
    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
    maxWidth: "600px",
    margin: "auto",
  }};
 export default SanjayGandhi;