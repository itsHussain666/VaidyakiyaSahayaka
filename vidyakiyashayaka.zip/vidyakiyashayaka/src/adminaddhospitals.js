// import React, { useState } from "react";

// const AddHospital=()=>{
//     const [addhospital,setaddhospital]=useState({
//         id:"",
//         name:"",
//         specialization:"",
//         location:"",
//     });

//     const handleSubmit = async (e) => {
//         e.preventDefault();
//     }
// }
import React, { useState } from "react";
import axios from "axios";

const AddHospital = () => {
  const [hospital, setHospital] = useState({
    id:"",
    name: "",
    specialization: "",
    location: "",
  });

  const handleChange = (e) => {
    setHospital({ ...hospital, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:5000/hospitals", hospital);
      alert("Hospital added successfully!");
      setHospital({ name: "", specialization: "", location: "" });
    } catch (error) {
      console.error("Error adding hospital:", error);
    }
  };

  const styles = {
    formContainer: {
      maxWidth: "400px",
      margin: "auto",
      padding: "20px",
      textAlign: "center",
      backgroundColor: "#f4f4f4",
      borderRadius: "10px",
      boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
    },
    input: {
      width: "100%",
      padding: "10px",
      margin: "10px 0",
      borderRadius: "5px",
      border: "1px solid #ccc",
    },
    button: {
      backgroundColor: "#008080",
      color: "white",
      padding: "10px 20px",
      border: "none",
      borderRadius: "5px",
      cursor: "pointer",
      fontSize: "16px",
    }
  };

  return (
    <div style={styles.formContainer}>
      <h2>Add a New Hospital</h2>
      <form onSubmit={handleSubmit}>
        <input 
        type="text"
        name="id"
        placeholder="id"
        style={styles.input}
        value={hospital.id}
        onChange={handleChange}
        required/>
        <input
          type="text"
          name="name"
          placeholder="Hospital Name"
          style={styles.input}
          value={hospital.name}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="specialization"
          placeholder="Specialization"
          style={styles.input}
          value={hospital.specialization}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="location"
          placeholder="Location"
          style={styles.input}
          value={hospital.location}
          onChange={handleChange}
          required
        />
        <button type="submit"  className="btn btn-primary" >Add Hospital</button>
      </form>
    </div>
  );
};

export default AddHospital;
