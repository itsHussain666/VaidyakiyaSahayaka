import { useState } from 'react';

function ReviewForm() {
    const [name, setName] = useState('');
    const [review, setReview] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        await fetch('http://localhost:5000/reviews', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ name, review })
        });
        alert('Review submitted!');
    };
    const styles = {
        container: {
        textAlign: "center",
        padding: "40px",
        fontFamily: "Arial, sans-serif",
        backgroundColor: "#f4f4f4",
        borderRadius: "10px",
        boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
        maxWidth: "500px",
        
        margin: "auto",
      },
      button: {
        backgroundColor: "#008080",
        color: "white",
        padding: "10px 20px",
        border: "none",
        borderRadius: "5px",
        cursor: "pointer",
        fontSize: "16px",
        marginTop: "15px",
      }
    };

    return (
        <form onSubmit={handleSubmit} style={styles.container}>
               <h1 align="center" className="cta-button"> Review</h1>
            <input  className='form-control' type="text" placeholder="Your Name" onChange={(e) => setName(e.target.value)} required />
           <br/>
            <textarea className='form-control' placeholder="Your Review" onChange={(e) => setReview(e.target.value)} required />
            <br/>
            <button className="btn btn-primary" type="submit">Submit</button>
        </form>
    );
}
export default ReviewForm;
