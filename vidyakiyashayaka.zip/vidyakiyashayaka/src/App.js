import { Routes,Route } from "react-router-dom";
import HomeMeterDoctor from "./home";
import Loginform from "./Login";
import Registration from "./Registration";
import FormPage from "./form";
import Jaydeva from "./hospitals/jaydeva hospital";
import SanjayGandhi from "./hospitals/sanjayhandhi";
import NIMHANS from "./hospitals/nimhans";
import IndiraGandhi from "./hospitals/indargandhi";
import KIMS from "./hospitals/kims";
import Victoria from "./hospitals/victoria";
import Bowring from "./hospitals/bowring";
import AboutUs from "./aboutus";
import AdminDashboard from "./admindash";
import Adminlogin from "./adminlogin";
import AdminMainDash from "./adminmaindash";
import AdminTotalHospitals from "./admintotalhospitals";
import AddHospital from "./adminaddhospitals";
import ReviewForm from "./userreview";
import AdminViewReview from "./adminviewrreview";
import ToDoList from "./To-do list/todolist";



export default function App(){
  return(
    <div>
      <Routes>
        <Route path="/" element={<HomeMeterDoctor></HomeMeterDoctor>}/>
        <Route path="/login" element={<Loginform></Loginform>}/>
        <Route path="/register" element={<Registration></Registration>}/>
        <Route path="/form" element={<FormPage></FormPage>}/>
        <Route path="Jayadeva Hospital" element={<Jaydeva></Jaydeva>}/>
        <Route path="Sanjay Gandhi Hospital" element={<SanjayGandhi></SanjayGandhi>}/>
        <Route path="NIMHANS Hospital" element={<NIMHANS></NIMHANS>}/>
        <Route path="Indra Gandhi Hospital" element={<IndiraGandhi></IndiraGandhi>}/>
        <Route path="KIMS Hospital" element={<KIMS></KIMS>}/>
        <Route path="Victoria Hospital" element={<Victoria></Victoria>}/>
        <Route path="Bowring and Lady Curzon Hospital" element={<Bowring></Bowring>}/>
        <Route path="/about" element={<AboutUs></AboutUs>}/>
        <Route path="/admindash" element={<AdminDashboard></AdminDashboard>}/>
        <Route path="/adminlogin" element={<Adminlogin></Adminlogin>}/>
        <Route path="/adminmaindash" element={<AdminMainDash></AdminMainDash>}/>
        <Route path="/admintotalhospitals" element={<AdminTotalHospitals></AdminTotalHospitals>}/>
        <Route path="/addhospitals" element={<AddHospital></AddHospital>}/>
        <Route path="/review" element={<ReviewForm/>}/>
        <Route path="/adminreview" element={<AdminViewReview></AdminViewReview>}/>
        <Route path="/todolist" element={<ToDoList></ToDoList>}/>
      </Routes>

    </div>
  )
}
