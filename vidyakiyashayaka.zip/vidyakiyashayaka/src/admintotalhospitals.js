import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const AdminTotalHospitals = () => {
  const [forms, setForms] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/hospitals")
      .then((res) => res.json())
      .then((data) => setForms(data))
      .catch((err) => console.error("Error fetching Hospitals:", err));
  }, []);
  const styles = {
    container: {
      textAlign: "center",
      padding: "50px",
      fontFamily: "Arial, sans-serif",
      backgroundColor: "#f4f4f4",
      borderRadius: "10px",
      boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
      maxWidth: "600px",
      margin: "auto",
    },
    button: {
      backgroundColor: "#008080",
      color: "white",
      padding: "10px 20px",
      border: "none",
      borderRadius: "5px",
      cursor: "pointer",
      fontSize: "16px",
      marginTop: "15px",
    }
  };


  return (
    <div style={styles.container}>
      <h2>Total Number of Hospitals</h2>
      <table border="1" className="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Specialization</th>
            <th>Location</th>
          </tr>
        </thead>
        <tbody>
          {forms.map((form) => (
            <tr key={form.id}>
              <td>{form.id}</td>
              <td>{form.name}</td>
              <td>{form.specialization}</td>
              <td>{form.location}</td>
              </tr>
          ))}
        </tbody>
      </table>
      <br/>
      <br/>
      <Link to="/addhospitals">
      <button className="btn btn-primary" >Add Hospitals +</button></Link>
    </div>
  );
};

export default AdminTotalHospitals;
