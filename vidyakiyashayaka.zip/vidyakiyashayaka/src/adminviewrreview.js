import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const AdminViewReview = () => {
  const [forms, setForms] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/reviews")
      .then((res) => res.json())
      .then((data) => setForms(data))
      .catch((err) => console.error("Error fetching Reviews:", err));
  }, []);
  
  const styles = {
    container: {
      textAlign: "center",
      padding: "50px",
      fontFamily: "Arial, sans-serif",
      backgroundColor: "#f4f4f4",
      borderRadius: "10px",
      boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
      maxWidth: "600px",
      margin: "auto",
    },
    button: {
      backgroundColor: "#008080",
      color: "white",
      padding: "10px 20px",
      border: "none",
      borderRadius: "5px",
      cursor: "pointer",
      fontSize: "16px",
      marginTop: "15px",
    }
  };


  return (
    <div style={styles.container}>
      <h2>Total Review's</h2>
      <table border="1" className="table">
        <thead>
          <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Review</th>
      
          </tr>
        </thead>
        <tbody>
          {forms.map((form) => (
            <tr key={form.id}>
              <td>{form.id}</td>
              <td>{form.name}</td>
              <td>{form.review}</td>
              </tr>
          ))}
        </tbody>
      </table>
      <br/>
      <br/>
      
    </div>
  );
};

export default AdminViewReview;
