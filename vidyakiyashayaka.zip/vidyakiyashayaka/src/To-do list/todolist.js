
// // import { useEffect, useState } from 'react';

// // function ToDoList() {
// //     const [title, setTitle] = useState('');
// //     const [description, setDescription] = useState('');
// //     const [completed,setCompleted]=useState('false')

// //     const [hospitalResults, setHospitalResults] = useState([]);
    
// //  const [forms, setForms] = useState([]);

// //   useEffect(() => {
// //     fetch("http://localhost:9091/todolist")
// //       .then((result) => result.json())
// //       .then((data) => setForms(data))
// //       .catch((err) => console.error("Error fetching Tasks:", err));
// //   }, []);

// //     const handleSubmit = async (e) => {
        
// //         try{
            
        
// //          const response=await fetch('http://localhost:9091/todolist', {
// //             method: 'POST',
// //             headers: {'Content-Type': 'application/json'},
// //             body: JSON.stringify({ title,description,completed})
// //         });
// //         alert('Task Added');
// //         const hospitals = await response.json();
// //         setHospitalResults(hospitals);
// //     }
// //         catch (error) {
// //             console.error("Error submitting task:", error);
// //           }
// //     };
    
// //     return (
// //         <div style={styles.container}>
// //         <form onSubmit={handleSubmit} style={styles.container}>
// //                <h1 align="center" className="cta-button"> To Do List</h1>
// //             <input  className='form-control' type="text" placeholder="Task Title" onChange={(e) => setTitle(e.target.value)} required />
// //            <br/>
// //             <textarea className='form-control' placeholder="Task Description" onChange={(e) => setDescription(e.target.value)} required />
// //             <br/>
// //             <button className="btn btn-primary" type="submit">Submit</button>
// //         </form>
// //         <h2>Previous Task </h2>
// //       <table border="1" className="table">
// //         <thead>
// //           <tr>
// //             <th>Id</th>
// //             <th>Title</th>
// //             <th>Description</th>
// //             <th>Completed</th>
// //             <th>Created Time</th>
      
// //           </tr>
// //         </thead>
// //         <tbody>
// //           {forms.map((form) => (
// //             <tr key={form.id}>
// //               <td>{form.id}</td>
// //               <td>{form.title}</td>
// //               <td>{form.description}</td>
// //               <td>{form.completed}</td>
// //               <td>{form.created_at}</td>
// //               </tr>
// //           ))}
// //         </tbody>
// //       </table>
        
// //         </div>
// //         );
        
    
  
// // }
// // const styles = {
// //     container: {
// //     textAlign: "center",
// //     padding: "40px",
// //     fontFamily: "Arial, sans-serif",
// //     backgroundColor: "#f4f4f4",
// //     borderRadius: "10px",
// //     boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
// //     maxWidth: "700px",
    
// //     margin: "auto",
// //   },
// //   button: {
// //     backgroundColor: "#008080",
// //     color: "white",
// //     padding: "10px 20px",
// //     border: "none",
// //     borderRadius: "5px",
// //     cursor: "pointer",
// //     fontSize: "16px",
// //     marginTop: "15px",
// //   }
// // };

// // export default ToDoList;

// import { useEffect, useState } from "react";

// function ToDoList() {
//   const [title, setTitle] = useState("");
//   const [description, setDescription] = useState("");
//   const [completed, setCompleted] = useState(false); // ✅ Fixed: Use boolean

//   const [tasks, setTasks] = useState([]);

//   // ✅ Fetch previous tasks on load
//   useEffect(() => {
//     fetch("http://localhost:9091/todolist")
//       .then((res) => res.json())
//       .then((data) => setTasks(data))
//       .catch((err) => console.error("Error fetching Tasks:", err));
//   }, []);

//   // ✅ Task Submission
//   const handleSubmit = async (e) => {
//     e.preventDefault(); // ✅ Prevents page reload

//     try {
//       const response = await fetch("http://localhost:9091/todolist", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ title, description, completed }),
//       });

//       if (!response.ok) throw new Error("Failed to add task");

//       alert("Task Added!");
//       const newTask = await response.json();
//       setTasks([...tasks, newTask]); // ✅ Update UI after submission
//     } catch (error) {
//       console.error("Error submitting task:", error);
//     }
//   };

//   return (
//     <div style={styles.container}>
//       <form onSubmit={handleSubmit} style={styles.container}>
//         <h1 align="center" className="cta-button">To-Do List</h1>
//         <input
//           className="form-control"
//           type="text"
//           placeholder="Task Title"
//           onChange={(e) => setTitle(e.target.value)}
//           required
//         />
//         <br />
//         <textarea
//           className="form-control"
//           placeholder="Task Description"
//           onChange={(e) => setDescription(e.target.value)}
//           required
//         />
//         <br />
//         <label>
//           <input
//             type="checkbox"
//             checked={completed}
//             onChange={(e) => setCompleted(e.target.checked)}
//           />
//           Mark as Completed
//         </label>
//         <br />
//         <button className="btn btn-primary" type="submit">Submit</button>
//       </form>
// <br/>
//       <h2>Previous Tasks</h2>
//       <table border="1" className="table">
//         <thead>
//           <tr>
//             <th>ID</th>
//             <th>Title</th>
//             <th>Description</th>
//             <th>Completed</th>
//             <th>Created Time</th>
//           </tr>
//         </thead>
//         <tbody>
//           {tasks.map((task) => (
//             <tr key={task.id}>
//               <td>{task.id}</td>
//               <td>{task.title}</td>
//               <td>{task.description}</td>
//               <td>{task.completed ? "✅ Yes" : "❌ No"}</td>
//               <td>{task.created_at}</td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// }

// // ✅ Styles
// const styles = {
//   container: {
//     textAlign: "center",
//     padding: "40px",
//     fontFamily: "Arial, sans-serif",
//     backgroundColor: "#f4f4f4",
//     borderRadius: "10px",
//     boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
//     maxWidth: "700px",
//     margin: "auto",
//   },
// };

// export default ToDoList;

import { useEffect, useState } from "react";

function ToDoList() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [completed, setCompleted] = useState(false);
  const [tasks, setTasks] = useState([]);

  // ✅ Fetch all tasks on page load
  useEffect(() => {
    fetch("http://localhost:9091/todolist")
      .then((res) => res.json())
      .then((data) => setTasks(data))
      .catch((err) => console.error("Error fetching tasks:", err));
  }, []);

  const handleUpdateStatus = async (id, isChecked) => {
    try {
      const response = await fetch(`http://localhost:9091/todolist/${id}`, {
        method: "PUT", // ✅ Updating task status
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ completed: isChecked }),
      });
  
      if (!response.ok) throw new Error("Failed to update task status");
  
      // ✅ Update the UI without refreshing
      setTasks(
        tasks.map((task) =>
          task.id === id ? { ...task, completed: isChecked } : task
        )
      );
    } catch (error) {
      console.error("Error updating task status:", error);
    }
  };
  
  // ✅ Add new task to the database & update UI
  const handleSubmit = async (e) => {
    
    try {
      const response = await fetch("http://localhost:9091/todolist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, description, completed }),
      });

      if (!response.ok) throw new Error("Failed to add task");

      alert("Task Added!");
      const newTask = await response.json();
      setTasks([...tasks, newTask]); // ✅ Update UI with new task
    } catch (error) {
      console.error("Error submitting task:", error);
    }
  };

  // ✅ Delete a specific row from the database & UI
  const handleDelete = async (id) => {
    try {
      const response = await fetch(`http://localhost:9091/todolist/${id}`, {
        method: "DELETE",
      });

      if (!response.ok) throw new Error("Failed to delete task");

      alert("Task Deleted!");
      setTasks(tasks.filter((task) => task.id !== id)); // ✅ Remove the deleted task from UI
    } catch (error) {
      console.error("Error deleting task:", error);
    }
  };

  return (
    <div style={styles.container}>
      <form onSubmit={handleSubmit} style={styles.form}>
        <h1 align="center" className="cta-button">To-Do List</h1>
        <input
          className="form-control"
          type="text"
          placeholder="Task Title"
          onChange={(e) => setTitle(e.target.value)}
          required
        />
        <br />
        <textarea
          className="form-control"
          placeholder="Task Description"
          onChange={(e) => setDescription(e.target.value)}
          required
        />
        <br />
        {/* <label>
          <input
            type="checkbox"
            checked={completed}
            onChange={(e) => setCompleted(e.target.checked)}
          />
          Mark as Completed
        </label> */}
        <br />
        <button className="btn btn-primary" type="submit">Submit</button>
      </form>

      <h2>Previous Tasks</h2>
      <table border="1" className="table">
        <thead>
          <tr>
            <th>Checked</th>
            <th>Title</th>
            <th>Description</th>
            <th>Completed</th>
            <th>Created Time</th>
            <th>Actions</th> {/* ✅ Added Actions Column */}
          </tr>
        </thead>
        <tbody>
          {/* {tasks.map((task) => (
            <tr key={task.id}>
               <td>
      <input
        type="checkbox"
        checked={task.completed} // ✅ Each row reflects correct completed status
        onChange={(e) => handleUpdateStatus(task.id, e.target.checked)} // ✅ Updates status on click
      />
    </td>
              <td>{task.description}</td>
              <td>{task.completed ? "✅ Yes" : "❌ No"}</td>
              <td>{task.created_at}</td>
              <td>
                <button
                  onClick={() => handleDelete(task.id)} // ✅ Deletes the selected row
                  style={styles.deleteButton}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))} */}
          {tasks.map((task) => (
  <tr key={task.id}>
    <td>
      <input
        type="checkbox"
        checked={task.completed} // ✅ Each row reflects correct completed status
        onChange={(e) => handleUpdateStatus(task.id, e.target.checked)} // ✅ Updates status on click
      />
    </td>
    <td>{task.title}</td>
    <td>{task.description}</td>
    <td>{task.completed ? "✅ Yes" : "❌ No"}</td>
    <td>{task.created_at}</td>
    <td>
      <button onClick={() => handleDelete(task.id)} style={styles.deleteButton}>
        Delete
      </button>
    </td>
  </tr>
))}

        </tbody>
      </table>
    </div>
  );
}

// ✅ Styles
const styles = {
  container: {
    textAlign: "center",
    padding: "40px",
    fontFamily: "Arial, sans-serif",
    backgroundColor: "#f4f4f4",
    borderRadius: "10px",
    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
    maxWidth: "700px",
    margin: "auto",
  },
  form: {
    maxWidth: "500px",
    margin: "auto",
  },
  deleteButton: {
    backgroundColor: "red", // ✅ Styled delete button in red
    color: "white",
    padding: "5px 10px",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    fontSize: "14px",
  },
};

export default ToDoList;
