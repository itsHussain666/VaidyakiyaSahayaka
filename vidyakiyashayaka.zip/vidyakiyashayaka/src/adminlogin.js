import React, { useState } from 'react';
import userDetailsService from './userDetailsService';
import { useNavigate } from 'react-router-dom';



export default function Adminlogin() {
  const [formData, setFormData] = useState({
    userName: '',
    password: '',
   
  });
  const navigate=useNavigate()


  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {

    e.preventDefault();
    userDetailsService.validateAdmin(formData.userName,formData.password).then((response)=>{
      if(response.status==200){
        alert("Welcome Admin");
        navigate("/adminmaindash")
      }
        else{
          alert("Try Again")
        }
      
    })
   
    console.log('Form submitted:', formData);
  };
  const styles = {
    container: {
      textAlign: "center",
      padding: "50px",
      fontFamily: "Arial, sans-serif",
      backgroundColor: "#f4f4f4",
      borderRadius: "10px",
      boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
      maxWidth: "600px",
      margin: "auto",
    },
    button: {
      backgroundColor: "#008080",
      color: "white",
      padding: "10px 20px",
      border: "none",
      borderRadius: "5px",
      cursor: "pointer",
      fontSize: "16px",
      marginTop: "15px",
    }
  };

  return (
    <form onSubmit={handleSubmit}  >
      <div style={styles.container}>
        <h1> Admin Log-in</h1>
        <div>
        <label>Admin ID : </label>
        <input
          className='form-control'
          required
          id="userName"
          
          placeholder="Enter Admin - Id"
          type="text"
          name="userName"
          value={formData.userName}
          onChange={handleChange}
        />
      </div>
      <div>
        <label>Password : </label>
        <input
         className='form-control'
         type="password"
          name="password"
          value={formData.password}
          onChange={handleChange}
        />
      </div>
      
      <br/>
      
      
      <button type="submit"  className="btn btn-primary"  >Login</button>

      </div>
      
     

    </form>
    
  );
}
