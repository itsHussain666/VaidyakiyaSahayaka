import React from "react";
import { Link,Outlet } from "react-router-dom";
import "./Home.css"; // Add styles

const Home = () => {
  return (
    <div className="home-container">
      {/* Navigation Bar */}
      <nav className="navbar">
        <h1>Vaidyakiya Sahayaka</h1>
        <div className="nav-links">
          <Link to="/login">Login</Link>
          <Link to="/register">Register</Link>
          <Link to="/about">About Us</Link>
          <Link to="/review">Review</Link>
        </div>
      </nav>

      {/* Welcome Section */}
      <div className="welcome-section">
        <h2>Helping You Find the Right Care, Instantly!</h2>
        <p>Easily find hospitals in Bangalore for the treatment you need. Fill out a quick form and get matched with the best medical facilities.</p>
        <Link to="/login" className="cta-button" onClick={() => alert('to Find a Hospital, Kindly LOG-IN ')}>Find a Hospital</Link>
        <br/>
        <br/>
        <p className="h2">
        Welcome to <strong>Vaidyakiya Sahayaka</strong> </p>,<p> your trusted healthcare assistance platform.
        Our mission is to connect patients with the right hospitals in Bangalore based on their medical needs.
      </p>
      <p>
        We aim to simplify access to healthcare and ensure timely treatment for those in need.
        With dedicated support and verified hospital information, we strive to make healthcare more accessible and transparent.
      </p>
      <h3>Our Vision</h3>
      <p>To create a seamless and efficient healthcare referral system for the people .</p>
        
      </div>
    </div>
  );
};

export default Home;
