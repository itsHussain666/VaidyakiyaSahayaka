import React from "react";

const AboutUs = () => {
  return (
    <div style={{ maxWidth: "600px", margin: "auto", textAlign: "center", padding: "20px" }}>
      <h2>About Us</h2>
      <p>
        Welcome to <strong>Vaidyakiya Sahayaka</strong>, your trusted healthcare assistance platform.
        Our mission is to connect patients with the right hospitals in Bangalore based on their medical needs.
      </p>
      <p>
        We aim to simplify access to healthcare and ensure timely treatment for those in need.
        With dedicated support and verified hospital information, we strive to make healthcare more accessible and transparent.
      </p>
      <h3>Our Vision</h3>
      <p>To create a seamless and efficient healthcare referral system for the people .</p><br/><br/>
      <h3>Contact Us:</h3>
      <h4>Phone No-123456</h4>
      <h4 style={{  paddingLeft : "20px" }}>E-mail:abc@gmail.com</h4>

      
    </div>
  );
};

export default AboutUs;


