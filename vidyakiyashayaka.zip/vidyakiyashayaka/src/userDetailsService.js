import axios from "axios";
class UserDetailsService{
    saveUserDetails(userdetails){
        return axios.post('http://localhost:9091/userdetails',userdetails)
    }
   validateUser(mobileNumber,password){
    return axios.get(`http://localhost:9091/userdetails/${mobileNumber}/${password}`)
   }
   validateAdmin(userName,password){
    return axios.get(`http://localhost:9091/admindetails/${userName}/${password}`)
   }
}
export default new UserDetailsService()