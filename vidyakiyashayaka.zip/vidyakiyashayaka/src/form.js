import React, { useState } from "react";
import { Link } from "react-router-dom";

const FormPage = () => {
  const [formData, setFormData] = useState({
    name: "",
    age: "",
    contact: "",
    symptoms: "",
    
    bloodgroup:"",
    adhaar:"",
    bpl:"",
  });

const [hospitalResults, setHospitalResults] = useState([]);

const handleChange = (e) => {
  const { name, value, type } = e.target;
  setFormData({
    ...formData,
    [name]: type === "file" ? e.target.files[0] : value,
  });
};

const handleSubmit = async (e) => {
  e.preventDefault();

  const formDataToSend = new FormData();
  Object.keys(formData).forEach((key) => {
    formDataToSend.append(key, formData[key]);
  });

  try {
    // Submit form details to the database
    await fetch("http://localhost:5000/submit-form", {
      method: "POST",
      body: formDataToSend,
    });

    // Fetch hospital recommendations
    const response = await fetch("http://localhost:5000/recommend-hospitals", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ symptoms: formData.symptoms }),
    });

    const hospitals = await response.json();
    setHospitalResults(hospitals);
  } catch (error) {
    console.error("Error submitting form:", error);
  }
};




 
  const styles = {
    container: {
      textAlign: "center",
      padding: "50px",
      fontFamily: "Arial, sans-serif",
      backgroundColor: "#f4f4f4",
      borderRadius: "10px", // // 🏥 Add state for hospital results
  // const [hospitalResults, setHospitalResults] = useState([]);

  // const handleSubmit = async (e) => {
  //   e.preventDefault();

  //   try {
  //     const response = await fetch("http://localhost:5000/recommend-hospitals", {
  //       method: "POST",
  //       headers: { "Content-Type": "application/json" },
  //       body: JSON.stringify({ symptoms: formData.symptoms }),
  //     });
      
  //     const hospitals = await response.json();
  //     setHospitalResults(hospitals); // ✅ Fix: Store results in state
  //   } catch (error) {
  //     console.error("Error fetching hospitals:", error);
  //   }
  // };
      boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
      maxWidth: "600px",
      margin: "auto",
    },
    button: {
      backgroundColor: "#008080",
      color: "white",
      padding: "10px 20px",
      border: "none",
      borderRadius: "5px",
      cursor: "pointer",
      fontSize: "16px",
      marginTop: "15px",
    }
  };

  return (
    <div className="form-container" style={styles.container}>
      <h2>Find the Right Hospital</h2>
      <form onSubmit={handleSubmit}>
        <input  className='form-control' type="text" name="name" placeholder="Full Name" onChange={handleChange} required />
        <br/>
        <input  className='form-control' type="number" name="age" placeholder="Age" onChange={(e) => setFormData({ ...formData, age: e.target.value })} required />
        <br/>
        <input  className='form-control' type="text" name="contact" placeholder="Contact Number" onChange={(e) => setFormData({ ...formData, contact: e.target.value })} required />
        <br/>
        <textarea className="form-control" type="text" name="discription" placeholder="Disease Discription" required/>
        <br/>
        <input type="radio"  name="gender"  value='Male' required/>Male&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <input type="radio" name="gender" value="Female"/>Female&nbsp;&nbsp;&nbsp;<input type="radio" name="gender" value="others"/>Others
        <br/>
        <input type="text" className="form-control" name="bloodtype" placeholder="Blood Group" onChange={(e) => setFormData({ ...formData, bloodgroup: e.target.value })} required/>
        <br/>
        <b>Any Diagnosis done?</b><br/>
        <input type="checkbox" name="diagnosis" value="test"/>Test&nbsp;&nbsp;&nbsp;<input type="checkbox" name="diagnosis" value="scan"/>Scan 
        &nbsp;&nbsp;&nbsp;<input type="checkbox" name="diagnosis" value="reports"/>Reports&nbsp;&nbsp;&nbsp;<input type="checkbox" name="diagnosis" value="priscription"/>Prescription(any)
        <br/> 
        <input className="form-control" type="file" name="file" placeholder="any report/scan"  required/>
        <br/>

          <b>Select an Appropriate Factor related to Disease</b>
        <select  className='form-control' onChange={(e) => setFormData({ ...formData, symptoms: e.target.value })} required >
            <option align="Center" >---Select-----</option>
            <option value="Cardiology">HEART</option>
            <option value="Neurology">BRAIN</option>
            <option value="Orthopedics">BONES</option>
            <option value="Child-Health">CHILD CARE</option>
            <option value="Multi-Speciality">MULTI-SPECIALITY</option>
        </select>
        <br/>
        <input type="text" className="form-control" name="adhaar" placeholder="Adhaar Number" max="12" onChange={(e) => setFormData({ ...formData, adhaar: e.target.value })} required/>
        <br/>
        <input type="text" className="form-control" name="bpl" placeholder="BPL Number" max="16" onChange={(e) => setFormData({ ...formData, bpl: e.target.value })} required/>
        
       {/* <textarea  className='form-control' name="symptoms" placeholder="Describe Your Symptoms" onChange={(e) => setFormData({ ...formData, symptoms: e.target.value })} required /> */}
            <br/>
        <button className="btn btn-primary" type="submit">Find Hospitals</button>
        <br/>
        <br/>
        <br/>

      </form>

      {/* Display hospital recommendations */}
      {hospitalResults.length > 0 && (
        <div className="results-container">
          <h2 className="text-light bg-dark">Recommended Hospitals</h2>
          <p>by, analysing the given details are: </p>
          <br/>
          <ul className="h5">
            {hospitalResults.map((hospital, index) => (
              
              <li key={index}>
                <strong>
                  <a href={hospital.name}>{hospital.name}</a></strong> - {hospital.specialization} ({hospital.location})
              </li>
            ))}
            
          </ul>
          
        </div>
      )}
    </div>
  );
};

export default FormPage;

