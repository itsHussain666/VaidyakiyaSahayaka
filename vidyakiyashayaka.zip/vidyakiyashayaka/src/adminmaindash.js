import React from "react";
import { Link } from "react-router-dom";

const AdminMainDash=()=>{
    const styles = {
          container: {
          textAlign: "center",
          padding: "40px",
          fontFamily: "Arial, sans-serif",
          backgroundColor: "#f4f4f4",
          borderRadius: "10px",
          boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
          maxWidth: "500px",
          height:"50px",
          margin: "auto",
        },
        button: {
          backgroundColor: "#008080",
          color: "white",
          padding: "10px 20px",
          border: "none",
          borderRadius: "5px",
          cursor: "pointer",
          fontSize: "16px",
          marginTop: "15px",
        }
      };

      return(
        <div>
          
           <h1 align="center" className="cta-button"> Welcome,to<br/> Admin's Dashboard</h1>
          
            
            <div style={styles.container}>
           <Link to="/admindash" ><button className="btn btn-primary"  >Total Form's Registered</button></Link>
            </div>
            <br/>
            <br/>
            <div style={styles.container}>
            <Link to="/admintotalhospitals" ><button className="btn btn-primary"  >Total Number of Hospitals</button></Link>

            </div>
            <br/>
            <br/>
            <div style={styles.container}>
           <Link to="/adminreview" ><button className="btn btn-primary"  >View Review's</button></Link>
            </div>
        </div>
      )
};
export default AdminMainDash;