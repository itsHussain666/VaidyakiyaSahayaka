import React, { useState } from 'react';
import userDetailsService from './userDetailsService';
import {useNavigate } from 'react-router-dom';

export default function Registration() {
  const [formData, setFormData] = useState({
    mobileNumber: '',
    password: '',
    confirmPassword: '',
    firstName: '',
    lastName: '',
    email: ''
  });
  const navigate=useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
     userDetailsService.saveUserDetails(formData).then(()=>{
          alert("User  registered Sucessfully")
          navigate("/login")
       })
    console.log('Form submitted:', formData);
  };
  const styles = {
    container: {
      textAlign: "center",
      padding: "50px",
      fontFamily: "Arial, sans-serif",
      backgroundColor: "#f4f4f4",
      borderRadius: "10px",
      boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
      maxWidth: "600px",
      margin: "auto",
    },
    button: {
      backgroundColor: "#008080",
      color: "white",
      padding: "10px 20px",
      border: "none",
      borderRadius: "5px",
      cursor: "pointer",
      fontSize: "16px",
      marginTop: "15px",
    }
  };

  return (
    <form onSubmit={handleSubmit} >
      <div style={styles.container}>
        <h1>REGISTER</h1>
        <div>
        <label>Mobile Number : </label>
        <input
          className='form-control'
          required
          id="mobileNumber"
          pattern="[0-9]{10}"
          placeholder="Enter 10-digit number"
          type="text"
          name="mobileNumber"
          value={formData.mobileNumber}
          onChange={handleChange}
        />
      </div>
      <div>
        <label>Password : </label>
        <input
         className='form-control'
         type="text"
          name="password"
          value={formData.password}
          onChange={handleChange}
        />
      </div>
      <div>
        <label>Confirm Password : </label>
        <input
                  className='form-control'

          type="text"
          name="confirmPassword"
          value={formData.confirmPassword}
          onChange={handleChange}
        />
      </div>
      <div>
        <label>First Name : </label>
        <input
                  className='form-control'

          type="text"
          name="firstName"
          value={formData.firstName}
          onChange={handleChange}
        />
      </div>
      <div>
        <label>Last Name : </label>
        <input
                  className='form-control'

          type="text"
          name="lastName"
          value={formData.lastName}
          onChange={handleChange}
        />
      </div>
      <div>
        <label>Email:</label>
        <input
                  className='form-control'

          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
        />
      </div>
      <br/>
      <button type="submit"  className="btn btn-primary"  >
        Register
      </button>
      <br/>
      <br/>
      Already have an account,<a href='login'>Log-in</a>
      </div>
    </form>
    
  );
  
}
