import cors from 'cors';
import express from 'express';
import mysql from 'mysql2/promise';     //npm install mysql2

var userapp = express();
userapp.use(express.json());
userapp.use(express.urlencoded());

userapp.use(cors())

const db = {
    host: "localhost",
    user: "root",
    password: 'root',
    database: 'itbridge'
};
// userapp.post("/todolist",  (req, res) => {
//     const { title,description,completed} = req.body;
//     // const file = req.file ? req.file.filename : null;
  
//     const query = `INSERT INTO tasks (title,description,completed) VALUES (?, ?, ?)`;
  
//     db.query (query, [title,description,completed], (err) => {
//       if (err) {
//         console.error("Error saving the task:", err);
//         res.status(500).send("Error saving the task");
//       } else {
//         res.status(200).json({ message: "Task added successfully!" });
//       }
//     });
//   });
 userapp.post('/todolist', async (req, res) => {
    try {
        //creates the connection
        const connection = await mysql.createConnection(db);
        //It will fetch data from body and assign it to individual variables.
        const {title,description,completed } = req.body; // Assuming data from React
        const [result] = await connection.execute(
            'INSERT INTO task(title,description,completed) VALUES (?,?,?)',
            [title,description,completed]
        );
        await connection.close();
        res.status(201).json({ message: 'Task added  successfully' });
    } catch (error) {
        console.error('Error inserting task:', error);
        res.status(500).json({ error: 'Failed to insert Task' });
    }
});
// userapp.get("/todolist", async function (request, response) {
//     try {
//         const connection = await mysql.createConnection(db);
//         const [result] = await connection.execute("SELECT * FROM task");
        
//         await connection.end(); // ✅ Close connection after query execution
        
//         if (result.length === 0) {
//             return response.status(204).json({ message: "No task found" }); // ✅ Correct response format
//         } else {
//             return response.status(200).json(result);
//         }
//     } catch (error) {
//         console.error("Database error:", error);
//         return response.status(500).json({ error: "Internal Server Error" });
//     }
// });

userapp.get('/todolist',async function (request,response) {
    const connection = await mysql.createConnection(db);
    const [result] = await  connection.execute('SELECT * FROM task');
    if (result.length == 0)
        return response.status(204).json(204,"no task found");   //all the visitors
    else
        return response.status(200).json(result)
});

userapp.delete("/todolist/:id", async function (request, response) {
    try {
        const { id } = request.params;
        const connection = await mysql.createConnection(db);
        const [result] = await connection.execute("DELETE FROM task WHERE id = ?", [id]);

        await connection.end(); // ✅ Close connection
        
        if (result.affectedRows === 0) {
            return response.status(404).json({ message: "Task not found" });
        }

        return response.status(200).json({ message: "Task deleted successfully" });
    } catch (error) {
        console.error("Error deleting task:", error);
        return response.status(500).json({ error: "Internal Server Error" });
    }
});
//save user
userapp.post('/userdetails', async (req, res) => {
    try {
        //creates the connection
        const connection = await mysql.createConnection(db);
        //It will fetch data from body and assign it to individual variables.
        const { mobileNumber, password, firstName, lastName, email } = req.body; // Assuming data from React
        const [result] = await connection.execute(
            'INSERT INTO userdetails VALUES (?,?,?,?,?)',
            [mobileNumber, password, firstName, lastName, email]
        );
        await connection.close();
        res.status(201).json({ message: 'Data inserted successfully' });
    } catch (error) {
        console.error('Error inserting data:', error);
        res.status(500).json({ error: 'Failed to insert data' });
    }
});
//get user and validate
//http://localhost:9091/userdetails/9663330910/mypass
userapp.get("/userdetails/:mobileNumber/:password", async function (request, response) {    //localhost:9090/visitors
    const mobileNumber = request.params.mobileNumber;
    const password = request.params.password;
    
    const connection = await mysql.createConnection(db);
    const [result] = await 
    connection.execute('SELECT * FROM userdetails where mobileNumber = ? and password = ? ', [mobileNumber, password]);
    if (result.length == 0)
        return response.status(204).json(204,"user not found");   //all the visitors
    else
        return response.status(200).json("user found,Welcome")
})
userapp.get("/admindetails/:userName/:password",async function (request,response) {
    const userName = request.params.userName;
    const password = request.params.password;

    const connection = await mysql.createConnection(db);
    const [result] = await 
    connection.execute('SELECT * FROM admindetails where userName = ? and password = ? ', [userName, password]);
    if (result.length == 0)
        return response.status(204).json(204,"user not found");   //all the visitors
    else
        return response.status(200).json("user found,Welcome")

    
})


userapp.listen("9091")
console.log("Userdetail app started on 9091");