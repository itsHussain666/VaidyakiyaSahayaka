// const express = require("express");
// const cors = require("cors");
// const mysql = require("mysql2");

// const app = express();
// app.use(cors());
// app.use(express.json());

// // Connect to MySQL Database
// const db = mysql.createConnection({
//   host: "localhost",
//   user: "root", // Your MySQL username
//   password: "root", // Your MySQL password
//   database: "hospital_db",
// });

// db.connect((err) => {
//   if (err) {
//     console.error("Error connecting to MySQL:", err);
//   } else {
//     console.log("Connected to MySQL Database");
//   }
// });

// // API to Submit Form Data
// app.post("/submit-form", (req, res) => {
//   const { name, age, contact, symptoms, bloodgroup, adhaar, bpl, file } = req.body;

//   const query = `
//     INSERT INTO forms (name, age, contact, symptoms, bloodgroup, adhaar, bpl, file) 
//     VALUES (?, ?, ?, ?, ?, ?, ?, ?)
//   `;

//   db.query(query, [name, age, contact, symptoms, bloodgroup, adhaar, bpl, file], (err, result) => {
//     if (err) {
//       console.error("Error inserting form data:", err);
//       res.status(500).send("Internal Server Error");
//     } else {
//       res.status(200).json({ message: "Form submitted successfully!" });
//     }
//   });
// });

// // API to Get All Submitted Forms (Admin View)
// app.get("/forms", (req, res) => {
//   db.query("SELECT * FROM forms", (err, results) => {
//     if (err) {
//       console.error("Error fetching forms:", err);
//       res.status(500).send("Internal Server Error");
//     } else {
//       res.json(results);
//     }
//   });
// });

// // API to Recommend Hospitals Based on Symptoms
// app.post("/recommend-hospitals", (req, res) => {
//   const { symptoms } = req.body;

//   const query = `SELECT * FROM hospitals WHERE specialization LIKE '%${symptoms}%'`;

//   db.query(query, (err, results) => {
//     if (err) {
//       console.error("Error fetching hospitals:", err);
//       res.status(500).send("Internal Server Error");
//     } else {
//       res.json(results.length ? results : [{ message: "No matching hospitals found" }]);
//     }
//   });
// });

// // Start Server
// const PORT = 5000;
// app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

const express = require("express");
const cors = require("cors");
const mysql = require("mysql2");
const multer = require("multer");

const app = express();
app.use(cors());
app.use(express.json());

// Configure Multer for File Uploads
const storage = multer.diskStorage({
  destination: "./uploads",
  filename: (req, file, cb) => {
    cb(null, Date.now() + "_" + file.originalname);
  },
});
const upload = multer({ storage });

// MySQL Database Connection
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root",
  database: "hospital_db",
});

db.connect((err) => {
  if (err) {
    console.error("Error connecting to MySQL:", err);
  } else {
    console.log("Connected to MySQL Database");
  }
});

app.post('/reviews', (req, res) => {
  const { name, review } = req.body;
  db.query('INSERT INTO reviews (name, review) VALUES (?, ?)', [name, review], (err, result) => {
      if (err) return res.status(500).json(err);
      res.json({ message: 'Review added!' });
  });
});

app.get('/reviews', (req, res) => {
  db.query('SELECT * FROM reviews', (err, result) => {
      if (err) return res.status(500).json(err);
      res.json(result);
  });
});
app.get("/hospitals", (req, res) => {
  db.query("SELECT * FROM hospitals", (err, results) => {
    if (err) {
      res.status(500).send(err);
      return;
    }
    res.json(results);
  });
});
app.post("/hospitals",(req,res)=>{
  const {id,name,specialization,location}=req.body;
  const query=`INSERT INTO hospitals(id,name,specialization,location) VALUES (?,?,?,?)`;
  db.query( query,[id,name,specialization,location],(err)=>{
    if(err){
      console.error("Error saving form data:", err);
      res.status(500).send("Error saving form data");
    } else {
      res.status(200).json({ message: "Form submitted successfully!" });
    }

    })
  })


// API to Submit Form Data
app.post("/submit-form", upload.single("file"), (req, res) => {
  const { id,name, age, contact, symptoms, bloodgroup, adhaar, bpl } = req.body;
  // const file = req.file ? req.file.filename : null;

  const query = `INSERT INTO forms (id,name, age, contact, symptoms, bloodgroup, adhaar, bpl) VALUES (?, ?, ?, ?, ?, ?, ?,?)`;

  db.query(query, [id,name, age, contact, symptoms, bloodgroup, adhaar, bpl], (err) => {
    if (err) {
      console.error("Error saving form data:", err);
      res.status(500).send("Error saving form data");
    } else {
      res.status(200).json({ message: "Form submitted successfully!" });
    }
  });
});

// API to Get All Submitted Forms (Admin View)
app.get("/forms", (req, res) => {
  db.query("SELECT * FROM forms", (err, results) => {
    if (err) {
      console.error("Error fetching forms:", err);
      res.status(500).send("Internal Server Error");
    } else {
      res.json(results);
    }
  });
});

// API to Recommend Hospitals Based on Symptoms
app.post("/recommend-hospitals", (req, res) => {
  const { symptoms } = req.body;

  const query = `SELECT * FROM hospitals WHERE specialization LIKE '%${symptoms}%'`;

  db.query(query, (err, results) => {
    if (err) {
      console.error("Error fetching hospitals:", err);
      res.status(500).send("Internal Server Error");
    } else {
      res.json(results.length ? results : [{ message: "No matching hospitals found" }]);
    }
  });
});

// Start Server
const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
